package com.example.musicfy.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.musicfy.Activities.PlayerActivity;
import com.example.musicfy.Modules.MusicFiles;
import com.example.musicfy.R;

import java.util.ArrayList;
import java.util.List;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.MyViewHolder> {

    private AdapterView.OnItemClickListener onItemClickListener;
   Context mContext;
   Bitmap bitmap;
   List<MusicFiles> arrayListSongs;
   ArrayList<String> arrayListUrl = new ArrayList<>();
   ArrayList<String> arrayListSong = new ArrayList<>();
   ArrayList<String> arrayListArtist = new ArrayList<>();
   ArrayList<String> arrayListImage = new ArrayList<>();



    public MusicAdapter(Context mContext, List<MusicFiles> arrayListSongs) {
        this.mContext = mContext;
        this.arrayListSongs = arrayListSongs;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(mContext).inflate(R.layout.songs_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {

        MusicFiles musicFiles = arrayListSongs.get(position);
        holder.song_name.setText(musicFiles.getSongTitle());
        holder.song_artist.setText(musicFiles.getArtist());
        holder.song_url.setText(musicFiles.getSongLink());
        holder.song_image_url.setText((musicFiles.getSongLink()));

       byte[] image = getAlbumArt(musicFiles.getSongLink());
       if(image != null){
           Glide.with(mContext).asBitmap()
                   .load(image)
                   .into(holder.song_cover);
       }else{
           Glide.with(mContext)
                   .load(R.drawable.music_cover)
                   .into(holder.song_cover);
       }


       if (!(arrayListUrl.contains(arrayListSongs.get(position).getSongLink())))
           arrayListUrl.add(arrayListSongs.get(position).getSongLink());
       if (!(arrayListSong.contains(arrayListSongs.get(position).getSongTitle())))
           arrayListSong.add(arrayListSongs.get(position).getSongTitle());
       if (!(arrayListArtist.contains(arrayListSongs.get(position).getArtist())))
           arrayListArtist.add(arrayListSongs.get(position).getArtist());
       if (!(arrayListImage.contains(arrayListSongs.get(position).getAlbum_art())))
           arrayListImage.add(arrayListSongs.get(position).getAlbum_art());


       holder.itemView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(mContext, PlayerActivity.class);
               intent.putExtra("song",holder.song_name.getText().toString());
               intent.putExtra("url",holder.song_url.getText().toString());
               intent.putExtra("artist",holder.song_artist.getText().toString());
               intent.putExtra("image",holder.song_image_url.getText().toString());

               intent.putExtra("arrayListUrl",arrayListUrl);
               intent.putExtra("arrayListSong",arrayListSong);
               intent.putExtra("arrayListArtist",arrayListArtist);
               intent.putExtra("arrayListImage",arrayListImage);
               intent.putExtra("position",String.valueOf(position));

               mContext.startActivity(intent);
           }
       });
    }

    @Override
    public int getItemCount() {
        return arrayListSongs.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder  implements  View.OnClickListener{

       TextView song_name,song_artist,song_url,song_image_url;
       ImageView song_cover;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            song_name = itemView.findViewById(R.id.music_name);
            song_artist = itemView.findViewById(R.id.music_artist);
            song_url = itemView.findViewById(R.id.music_url);
            song_cover = itemView.findViewById(R.id.music_img);
            song_image_url = itemView.findViewById(R.id.music_image_url);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {


//            ((PlayerActivity)mContext).playMusic(arrayListSongs,getAdapterPosition());


//            try {
//                ((SearchActivity)mContext).playSong(arrayListSongs,getAdapterPosition());
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
        }
    }

    private byte[] getAlbumArt(String uri){
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(uri);
        byte[] art = retriever.getEmbeddedPicture();
        retriever.release();
        return art;
    }
}
