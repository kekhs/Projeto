package com.example.musicfy.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.musicfy.Adapters.MusicAdapter;
import com.example.musicfy.Fragments.SearchFragment;
import com.example.musicfy.Modules.MusicFiles;
import com.example.musicfy.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    DatabaseReference databaseReference;
    FirebaseStorage mStorage;
    ValueEventListener valueEventListener;
    MediaPlayer mediaPlayer;

    RecyclerView recyclerView;
    ProgressBar progressBar;
    List<MusicFiles> mUpload;

    MusicFiles musicFiles;
    MusicAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        recyclerView = findViewById(R.id.recycler_view);
        progressBar = findViewById(R.id.progress_showSongs);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mUpload = new ArrayList<>();

        adapter = new MusicAdapter(SearchActivity.this, mUpload);
        recyclerView.setAdapter(adapter);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("songs");

        valueEventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUpload.clear();
                for (DataSnapshot dss : snapshot.getChildren()) {
                    MusicFiles musicFiles = dss.getValue(MusicFiles.class);
                    musicFiles.setmKey(dss.getKey());
                    mUpload.add(musicFiles);
                }

                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseReference.removeEventListener(valueEventListener);
    }


//    public void playSong(List<MusicFiles> arrayListSongs, int adapterPosition) throws IOException {
//
//        MusicFiles musicFiles = arrayListSongs.get(adapterPosition);
//
//        if (mediaPlayer != null)
//        {
//            mediaPlayer.stop();
//            mediaPlayer.release();
//            mediaPlayer = null;
//        }
//
//        mediaPlayer = new MediaPlayer();
//
//        mediaPlayer.setDataSource(musicFiles.getSongLink());
//        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//            @Override
//            public void onPrepared(MediaPlayer mediaPlayer) {
//                mediaPlayer.start();
//            }
//        });
//
//        mediaPlayer.prepareAsync();
//    }

}
