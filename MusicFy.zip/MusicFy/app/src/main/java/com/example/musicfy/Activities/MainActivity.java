package com.example.musicfy.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;

import com.example.musicfy.Fragments.HomeFragment;
import com.example.musicfy.Fragments.SearchFragment;
import com.example.musicfy.Modules.MusicFiles;
import com.example.musicfy.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private FrameLayout fragmentHolder;
    public BottomNavigationView bottom_bar;

    private FirebaseStorage storage;
    private StorageReference storageRef;

    ImageButton uploadButton;

    public static ArrayList<MusicFiles> musicFiles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragmentHolder = findViewById(R.id.main_frame_layout);

        uploadButton = findViewById(R.id.upload_btn);

        bottom_bar = findViewById(R.id.bottom_bar);
        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame_layout,new HomeFragment()).commit();

        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,UploadActivity.class);
                startActivity(intent);
            }
        });

        bottom_bar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedfragment = null;

                switch (item.getItemId()){
                    case R.id.home:
                        selectedfragment = new HomeFragment();
                        break;
                    case R.id.search:
                         selectedActivity();
                        break;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.main_frame_layout,selectedfragment).commit();
                return true;
            }
        });
    }

    private void selectedActivity() {
        Intent intent = new Intent(MainActivity.this,SearchActivity.class);
        startActivity(intent);
    }
}