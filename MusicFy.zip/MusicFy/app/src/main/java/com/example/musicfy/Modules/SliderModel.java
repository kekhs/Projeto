package com.example.musicfy.Modules;

public class SliderModel {
    private int Image;
    private String sliderName;

    public SliderModel(int image, String sliderName) {
        Image = image;
        this.sliderName = sliderName;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

    public String getSliderName() {
        return sliderName;
    }

    public void setSliderName(String sliderName) {
        this.sliderName = sliderName;
    }
}
