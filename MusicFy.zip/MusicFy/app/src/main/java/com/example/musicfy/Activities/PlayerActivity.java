package com.example.musicfy.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.musicfy.Modules.MusicFiles;
import com.example.musicfy.R;

import java.io.IOException;
import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity {

    TextView music_name, music_artist, duration_played, duration_total;
    ImageButton nextBtn, prevBtn, backBtn, volupBtn, voldownBtn,playBtn,pauseBtn;
    ImageView cover_art;
    SeekBar seekBar;

    MusicFiles musicFiles;

    MediaPlayer mediaPlayer;
    Handler handler;

    String out,out2;
    Integer difference;
    Integer position;

    ArrayList<String> arrayListUrl;
    ArrayList<String> arrayListSong;
    ArrayList<String> arrayListImage;
    ArrayList<String> arrayListArtist;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        music_name = findViewById(R.id.song_name);
        music_artist = findViewById(R.id.song_artist);
        duration_played = findViewById(R.id.durationPlayed);
        duration_total = findViewById(R.id.durationTotal);
        cover_art = findViewById(R.id.cover_art);

        playBtn = findViewById(R.id.playBtn);
        pauseBtn = findViewById(R.id.pauseBtn);
        nextBtn = findViewById(R.id.id_next);
        prevBtn = findViewById(R.id.id_previous);
        backBtn = findViewById(R.id.back_btn);
        voldownBtn = findViewById(R.id.volume_low);
        volupBtn = findViewById(R.id.volume_up);
        seekBar = findViewById(R.id.seekBar);

        mediaPlayer = new MediaPlayer();
        handler = new Handler();


        Intent i = getIntent();
        String song = i.getStringExtra("song");
        String url = i.getStringExtra("url");
        String artist = i.getStringExtra("artist");
        String image = i.getStringExtra("image");

        arrayListUrl = i.getStringArrayListExtra("arrayListUrl");
        arrayListSong = i.getStringArrayListExtra("arrayListSong");
        arrayListArtist = i.getStringArrayListExtra("arrayListArtist");
        arrayListImage = i.getStringArrayListExtra("arrayListImage");
        position = Integer.parseInt(i.getStringExtra("position"));

        init(song,artist,url,image);


        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Pause();
            }
        });

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Play();
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (arrayListUrl.size() == position + 1){
                    position = 0;
                    init(arrayListSong.get(position),arrayListArtist.get(position),arrayListUrl.get(position),arrayListImage.get(position));
                }
                else{
                    position = position + 1;
                    init(arrayListSong.get(position),arrayListArtist.get(position),arrayListUrl.get(position),arrayListImage.get(position));
                }
            }
        });

        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (position == 0){
                    position = arrayListUrl.size() - 1;
                    init(arrayListSong.get(position),arrayListArtist.get(position),arrayListUrl.get(position),arrayListImage.get(position));
                }
                else{
                    position = position - 1;
                    init(arrayListSong.get(position),arrayListArtist.get(position),arrayListUrl.get(position),arrayListImage.get(position));
                }
            }
        });


        initializeSeekBar();
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if(fromUser){
                    mediaPlayer.seekTo(progress*1000);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }

    private void init(String song, String artist, String url, String image) {
        music_name.setText(song);
        music_artist.setText(artist);

        cover_art.setImageResource(R.drawable.music_cover);

        if(mediaPlayer.isPlaying()){
            mediaPlayer.stop();
        }

        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaPlayer.start();
        initializeSeekBar();

    }

    private void initializeSeekBar() {
        seekBar.setMax(mediaPlayer.getDuration()/1000);

        PlayerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaPlayer != null){
                    int mCurrentPosition = mediaPlayer.getCurrentPosition() /1000;
                    seekBar.setProgress(mCurrentPosition);

                    out = String.format("%02d:%02d",seekBar.getProgress() / 60 ,seekBar.getProgress() % 60 );
                    //this will store string of time in min and sec
                    duration_played.setText(out);

                    difference = mediaPlayer.getDuration()/1000 - mediaPlayer.getCurrentPosition()/1000;

                    out2 = String.format("%02d:%02d", difference / 60 , difference % 60);
                    duration_total.setText(out2);

                }
                handler.postDelayed(this,1000);
            }
        });
    }

    private void Play() {
        mediaPlayer.start();
        playBtn.setVisibility(View.INVISIBLE);
        pauseBtn.setVisibility(View.VISIBLE);
    }

    private void Pause() {
        mediaPlayer.pause();
        playBtn.setVisibility(View.VISIBLE);
        pauseBtn.setVisibility(View.INVISIBLE);
    }

//    private byte[] getAlbumArt(){
//        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
//        retriever.setDataSource(url);
//        byte[] art = retriever.getEmbeddedPicture();
//        retriever.release();
//        return art;
//    }



//    public void playMusic(List<MusicFiles> arrayListSongs, int adapterPosition) {
//        MusicFiles musicFiles = arrayListSongs.get(adapterPosition);
//
//        music_name.setText(musicFiles.getSongTitle());
//        artist_name.setText(musicFiles.getArtist());
//
//    }
}