package com.example.musicfy.Fragments;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.example.musicfy.Activities.RegisterActivity;
import com.example.musicfy.Adapters.SliderAdapter;
import com.example.musicfy.Modules.SliderModel;
import com.example.musicfy.R;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private ViewPager slider;
    private ArrayList<SliderModel> sliderModelList;
    private SliderAdapter sliderAdapter;
    private TabLayout sliderIndicator;
    private ImageButton btnLogOut;
    private FirebaseAuth mAuth;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        slider = view.findViewById(R.id.slider);
        sliderIndicator = view.findViewById(R.id.slide_indicator);

        sliderModelList = new ArrayList<>();
        sliderModelList.add(new SliderModel(R.drawable.genre_eletro, "Eletro House"));
        sliderModelList.add(new SliderModel(R.drawable.genre_funk, "Funk"));
        sliderModelList.add(new SliderModel(R.drawable.genre_latin, "Latin"));

        sliderAdapter = new SliderAdapter(getContext(), sliderModelList);
        slider.setAdapter(sliderAdapter);

        mAuth = FirebaseAuth.getInstance();


        btnLogOut = view.findViewById(R.id.log_out);

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signOutWithFirebase();
            }
        });


        sliderIndicator.setupWithViewPager(slider);
        return view;

    }

    private void signOutWithFirebase() {
        mAuth.getInstance().signOut();
        Intent intent = new Intent(getActivity(), RegisterActivity.class);
        getActivity().startActivity(intent);
        getActivity().finish();
    }

}