package com.example.musicfy.Fragments;

import static com.example.musicfy.Activities.MainActivity.musicFiles;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.musicfy.Adapters.MusicAdapter;
import com.example.musicfy.Modules.MusicFiles;
import com.example.musicfy.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SearchFragment extends Fragment {

//    RecyclerView recyclerView;
//    Uri uri;
//    MusicAdapter musicAdapter;
//    DatabaseReference databaseReference;
//    ListView listView;
//    ArrayList<String> arrayListSongsName = new ArrayList<>();
//    ArrayList<String> arrayListSongsUrl = new ArrayList<>();
//    ArrayAdapter<String> arrayAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

//        listView = view.findViewById(R.id.myListView);

//        retrieveSongs();



//        recyclerView = view.findViewById(R.id.recyclerView);
//        recyclerView.setHasFixedSize(true);
//        if(!(musicFiles.size() < 1)){
//            musicAdapter = new MusicAdapter(getContext(),musicFiles);
//            recyclerView.setAdapter(musicAdapter);
//            recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.VERTICAL,false));
//        }
        return view;
    }

//    private void retrieveSongs() {
//
//        databaseReference = FirebaseDatabase.getInstance().getReference("Songs");
//
//        databaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                for (DataSnapshot ds: dataSnapshot.getChildren()){
//
//                    MusicFiles songObj = ds.getValue(MusicFiles.class);
//                    arrayListSongsName.add(songObj.getSongTitle());
//                    arrayListSongsUrl.add(songObj.getSongLink());
//                }
//
//                arrayAdapter = new ArrayAdapter<String>(SearchFragment.this,android.R.layout.simple_list_item_1,arrayListSongsName);
//                listView.setAdapter(arrayAdapter);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
}